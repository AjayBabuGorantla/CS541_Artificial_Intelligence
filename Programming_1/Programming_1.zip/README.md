Instructions for executing this code:

compile main.py file

You will be prompted to enter the order of the puzzle (i.e. 3 if 3X3 puzzle)

Then start entering the values of the puzzle. Hit 'Enter' after entering each value(input)

After the 9th input value, the program will determine if the goal state is achievable and search for path using 
greedy best first search and A* search algorithms, and return the solution path and number of steps taken to reach the goal.


